x=input()
x=int(x)
n=0
while True:
    y=x//(10**n)
    if y<1:
        break
    else:
        n+=1
mm=[0 for i in range (0,n)]
print(f'输入的数有{n}位')
for i in range (n):
    z=x//(10**(n-i-1))
    mm[i]=z
    x=x-z*(10**(n-i-1))
zt=['个','十','百','千','万','十万','百万','千万','亿','十亿','百亿','千亿','万亿','十万亿','百万亿','千万亿']
print(mm)
for j in range(n):
    print(f'第{zt[n-1-j]}位为{mm[j]}')