xx=[5,9,4,-2,1,2**0.5,6,3.1415926,-4/3,5.13]
max_xx=min_xx=xx[0]
sum=0
for i in range(10): 
    if xx[i]>max_xx:
        max_xx=xx[i]
    if xx[i]<min_xx:
        min_xx=xx[i]
    sum=sum+xx[i]
adv=sum/10
print(f'最大值为{max_xx}')
print(f'最小值为{min_xx}')
print(f'平均值为{adv}')