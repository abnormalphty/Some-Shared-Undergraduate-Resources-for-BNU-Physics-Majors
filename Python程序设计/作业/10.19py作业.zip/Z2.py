xx=[5,9,4,-2,1,2**0.5,6,3.1415926,-4/3,5.13]
for i in range(len(xx)-1):
    max_p=i
    for j in range(i,len(xx)):
        if xx[max_p]<xx[j]:
            max_p=j
    xx[i],xx[max_p]=xx[max_p],xx[i]
print(xx)