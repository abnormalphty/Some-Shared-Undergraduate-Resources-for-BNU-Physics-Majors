xx=[5,9,4,-2,1,2**0.5,6,3.1415926,-4/3,5.13]
c=0
for i in range(len(xx)-1):
    for j in range(len(xx)-1-i):
        if xx[j]>xx[j+1]:
            xx[j],xx[j+1]=xx[j+1],xx[j]
            c+=1
    if c==0:
        break
print(xx)