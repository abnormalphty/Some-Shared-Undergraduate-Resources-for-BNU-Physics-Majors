import numpy as np
list1 = [[1, 2, 3], [4, 5, 6]]
list2 = [[7, 8, 9], [10, 11, 12]]
array1 = np.array(list1)
array2 = np.array(list2)
print(array1)
print(array2)
#[学号已脱敏] 学生